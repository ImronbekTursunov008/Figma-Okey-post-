import React from 'react'
import { SlUser } from "react-icons/sl";
import { NavLink , Link } from 'react-router-dom';


function Navbar({modal,setModal}) {
   

  const showModal = ()=>{
    setModal(true)
    console.log(modal);
  }
  return (
    <div className='container'>
          <div className='navbar'>
        <NavLink to={"/"}><img src="./public/image/logo.png" alt="" /></NavLink> 
        <div className='about'>
            <Link className='none' to={"/howbuy"}><h3>Как покупать</h3></Link>
            <h3>Распродажи</h3>
            <h3>Цены</h3>
            <h3>Помощь</h3>
            <Link className='none' to={"/bonus"}><h3>Бонусы</h3></Link> 
            <Link className='none' to={"/blog"}><h3>Блог</h3></Link>
            <Link className='none' to={"/magazine"}><h3>Магазины</h3></Link>
        </div>
        <div className='login'>
            <div onClick={showModal} className="user">
            <SlUser />
            <h4>Вход</h4>
            </div>
            <button className='phoneBtn'>
            Связаться с нами
            </button>
        </div>
    </div>
    </div>
  )
}

export default Navbar