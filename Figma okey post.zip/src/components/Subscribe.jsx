import React from 'react'
import './subscribe.css'
import { MdOutlineEmail } from "react-icons/md";
function Subscribe() {
  return (
    <div className='subscribe'>
        <div className="container">
            <h1>Подпишитеть и будьте в курсе всех скидок и акций магазинов Великобритании!</h1>
            <div className='email'>
            <MdOutlineEmail />
            <input type="text" placeholder='Введите ваш email' />
            </div>
             <button className='finalBtn'>
             Подписаться
             </button>
        </div>
    </div>
  )
}

export default Subscribe