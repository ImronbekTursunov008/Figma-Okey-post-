import React from 'react'
import './offer.css'

function Offers() {
  return (
   <div className="container">
    <div className='offers'>
    <div className="client">
        <h1>120 000 довольных клиентов в России уже сделали свой выбор</h1>
        <h5>За последний год десятки тысяч наших клиентов заказали товары из Англии и оставили 19 633 отзыва</h5>
        <div className="benefits">
            <div className="benefit">
                <img src="./public/image/notbig.png" alt="" />
                <h3>Больше не значит дороже</h3>
                <p>С ростом веса посылки цена за каждые 0.5 кг уменьшается в прогрессии.</p>
            </div>
            <div className="benefit">
                <img src="./public/image/fastest.png" alt="" />
                <h3>Быстрая обработка посылок</h3>
                <p>Посылка обрабатывается не дольше 48 часов после поступления на склад.</p>
            </div>
            <div className="benefit">
                <img src="./public/image/sms.png" alt="" />
                <h3>SMS-уведомления</h3>
                <p>Отслеживайте весь процесс с помощью sms-уведомлений.</p>
            </div>
        </div>
    </div>
    <div className="reviews">
        <h1>Отзывы и цитаты блогеров:</h1>
        <div className="supports">
            <div className="review">
                <img src="./public/image/niko.png" alt="" />
                <div className='supInfo'>
                    <h2>NIKOLAY S</h2>
                    <img className='rate' src="./public/image/rate.png" alt="" />
                    <p>Ваша доставка самая быстрая и дешёвая!!!</p>
                    <h3>Дата: <span className='low'>
                        16 Ноября 2021</span></h3>
                        <h4>Город : <span className='low'>
                        Санкт-Петербург
                        </span>
                        </h4>
                </div>
            </div>
            <div className="review">
                <img src="./public/image/dima.png" alt="" />
                <div className='supInfo'>
                    <h2>DMITRIY D</h2>
                    <img className='rate' src="./public/image/rate.png" alt="" />
                    <p>Пуховик Levi’s c eBay. Всё приехало быстро и целым.</p>
                    <h3>Дата: <span className='low'>
                        16 Ноября 2021</span></h3>
                        <h4>Город : <span className='low'>
                        Москва
                        </span>
                        </h4>
                </div>
            </div>
            <div className="review">
                <img src="./public/image/vlad.png" alt="" />
                <div className='supInfo'>
                    <h2>VLADIMIR E</h2>
                    <img className='rate' src="./public/image/rate.png" alt="" />
                    <p>Огонь, как всегда! Отдельное спасибо за доп.упаковку, часики от Apple пришли в простом бумажном пакете )</p>
                    <h3>Дата: <span className='low'>
                        16 Ноября 2021</span></h3>
                        <h4>Город : <span className='low'>
                        Санкт-Петербург
                        </span>
                        </h4>
                </div>
            </div>
            <div className="review">
                <img src="./public/image/oksana.png" alt="" />
                <div className='supInfo'>
                    <h2>Оксана</h2>
                    <img className='rate' src="./public/image/rate.png" alt="" />
                    <p>Очень быстро, надежно! Как всегда большое спасибо за работу!</p>
                    <h3>Дата: <span className='low'>
                        16 Ноября 2021</span></h3>
                        <h4>Город : <span className='low'>
                        Odintsovo
                        </span>
                        </h4>
                </div>
            </div>
        </div>
        <button className='allBtn'>
        Все отзывы
        </button>
    </div>
    <div className="adress">
        <h1>Ваш личный адрес в Великобритании  для покупок</h1>
        <p>С нами вы получаете целых два адреса в UK! У нас есть два склада для приема посылок – в Лондоне и Манчестере. Указывайте в магазине тот из них, отправка на который обойдется дешевле (или покупка будет без налогов). Чаще всего в Лондоне наши клиенты заказывают одежду и обувь, а в Манчестер идут гаджеты и всё остальное. С OkeyPost вы всегда получаете максимальную выгоду!

При доставке из UK в Россию все ваши товары обязательно страхуются. Прием посылок на наш склад, их обработка, удаление лишних коробок, хранение сроком до 70 дней – у нас полностью бесплатно. Мы также бесплатно проводим объединение посылок из разных магазинов в одну. Это необходимо для снижения стоимости доставки посылок из UK в Россию.

У нас самая выгодная доставка! От $11.99 за посылку! А если у вас есть какие-то особенные требования, вроде проверки техники или дополнительной пленки для самых хрупких товаров, – операторы нашего склада с радостью выполнят их по спецзапросу.

Okeypost.com – это надежно, быстро и выгодно. А в наших соцсетях вы всегда найдете информацию о лучших скидках fyukbqcrb магазинов. Не обязательно заходить в Черную пятницу или Prime Day, крутые акции проходят каждый день!</p>
    </div>
    </div>
   </div>
    )
}

export default Offers