import React from 'react'
import './support.css'

function Support() {
  return (
    <div className='support'>
        <div className="container">
            <img src="./public/image/tv.png" alt="" />
            <div className="title">
            <h1>Виртуальный тур по нашему складу в реальном времени</h1>
            <p>Вы можете всегда посмотреть на нашу слаженую работу на складе</p>
            <button className='againBtn'>
            Попробовать
            </button>
            </div>

        </div> 
    </div>
  )
}

export default Support