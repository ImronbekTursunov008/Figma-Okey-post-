import React from 'react'
import './delevery.css'

function Delevery() {
  return (
    <div className="delevery">
   <div className="container">
        <div className="left">
     <h1>Доставка товаров из Великобритании в Россию</h1>
     <p>Начните экономить до 80% на шопинге. Регистрируйтесь в OkeyPost, чтобы покупать со скидками в UK одежду, обувь, гаджеты известных брендов и безопасно отправлять вещи в Россию.
     </p>
     <button className='ukBtn'>Получить адрес в UK</button>
    </div>
    <div className="right">
     <img src="./public/image/ill.png" alt="" />
    </div>
   </div>
 </div>

  )
}

export default Delevery