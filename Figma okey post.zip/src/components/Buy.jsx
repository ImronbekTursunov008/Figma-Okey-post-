import React from 'react'
import './buy.css'

function Buy() {
  return (
    <div className='buy'>
        <div className="container">
            <img src="./public/image/ill2.png" alt="" />
            <div className='try'>
               <h2>Поручите нашим мастерам шопинга оформить заказы в английских магазинах и освободите время для более важных дел.</h2>
               <p>Такой способ покупки также подойдёт, если магазин принимает только английские карты.</p>
               <button className='tryBtn'>Попробовать</button>
            </div>
        </div>
    </div>
  )
}

export default Buy