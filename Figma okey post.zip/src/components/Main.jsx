import React from 'react'
import Buy from './Buy'
import Delevery from './Delevery'
import './main.css'
import Offers from './Offers'
import Road from './Road'
import Sell from './Sell'
import Subscribe from './Subscribe'
import Support from './Support'

function Main() {
  return (
    <div className='main'>
       <Delevery/>
       <Sell/>
       <Buy/>
       <Road/>
       <Support/>
       <Offers/>
       <Subscribe/>
    </div>
  )
}

export default Main