import React from "react";
import './footer.css'

function Footer() {
  return (
    <div className="container">
      <div className="footer">
        <div className="okey">
            <img src="./public/image/logo.png" alt="" />
            <img src="./public/image/social.png" alt="" />
        </div>
        <div className="company">
            <h4>О компании</h4>
            <h5>Услуги</h5>
            <h5>Цены</h5>
            <h5>Отзывы</h5>
            <h5>Контакты</h5>
            <h5>Вакансии</h5>
            <h5>Соглашение о персональных данных</h5>
            <h5>Условия использования</h5>
        </div>
        <div className="beneit">
            <h4>Полезное</h4>
            <h5>Как работает наш сервис</h5>
            <h5>Как покупать с оператором
</h5>
            <h5>Ответы на частые вопросы
</h5>
            <h5>Популярные магазины
</h5>
            <h5>Черный список магазинов
</h5>
            <h5>Актуальные распродажи</h5>
        </div>
        <div className="projects">
            <h4>Спецпроекты</h4>
            <h5>50% на первую доставку</h5>
            <h5>Скидки для постоянных клиентов
</h5>
            <h5>Реферальная программа
</h5>
            <h5>Кэшбек Mr. Rebates и Rakuten
</h5>
            <h5>Stop Fraud</h5>
        </div>
      </div>
    </div>
  );
}

export default Footer;
