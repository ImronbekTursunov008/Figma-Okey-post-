import React from "react";
import { MdOutlineSportsVolleyball } from "react-icons/md";
import { LiaCitySolid } from "react-icons/lia";
import { TbMessageMinus } from "react-icons/tb";
import { GiWeightLiftingUp } from "react-icons/gi";
import { GrDocumentText } from "react-icons/gr";
import "./road.css";

function Road() {
  return (
    <div className="container">
      <div className="road">
        <div className="form">
          <h1>
            OkeyPost удобная и быстрая доставка посылок из Великобритании{" "}
          </h1>
          <h6 className="style">
            Рассчитайте стоимость доставки из Англии к вам домой. Мы получим
            ваши посылки на складе, при необходимости объединим несколько
            доставок в одну и отправим их к вам надежно упакованными.
          </h6>
          <div className="write">
            <div className="count">
              <div className="country">
                <h5>Страна:</h5>
                <div className="withIcon">
                  <MdOutlineSportsVolleyball />
                  <h6>Россия</h6>
                </div>
              </div>
              <div className="city">
                <h5>Город:</h5>
                <div className="withIcon">
                  <LiaCitySolid />
                  <h6>Москва</h6>
                </div>
              </div>
              <div className="index">
                <h5>Индекс:</h5>
                <div className="withIcon">
                  <TbMessageMinus />
                  <h6>Введите индекс</h6>
                </div>
              </div>
              <div className="weight">
                <h5>Вес посылки:</h5>
                <div className="withIcon">
                  <GiWeightLiftingUp />
                  <h6>0,5</h6>
                </div>
              </div>
              <div className="occasion">
                <h5>Дополнительные услуги:</h5>
                <div className="withIcon">
                  <GrDocumentText />
                  <h6>Выберите услуги</h6>
                </div>
              </div>
            </div>
            <button className="countBtn">Рассчитать</button>
          </div>
        </div>
        <div className="variants">
          <h1>Варианты доставки:</h1>
          <div className="variant">
            <div className="imgand">
              <img src="./public/image/messag.png" alt="" />
              <h2>Почта России</h2>
            </div>
            <div className="roadInfo">
              <div className="time">
                <h6>Сроки:</h6>
                <h5>10-14 дней</h5>
              </div>
              <div className="delPrice">
                <h6>Стоимость доставки:</h6>
                <h5>от £27.00</h5>
              </div>
              <div className="all">
                <h6>Итого:</h6>
                <h5>£41.99</h5>
              </div>
            </div>
          </div>
          <div className="variant">
            <div className="imgand">
              <img src="./public/image/ems.png" alt="" />
              <h2>EMS ПОЧТА РОССИЯ</h2>
            </div>
            <div className="roadInfo">
              <div className="time">
                <h6>Сроки:</h6>
                <h5>09-12 дней</h5>
              </div>
              <div className="delPrice">
                <h6>Стоимость доставки:</h6>
                <h5>от £40.00</h5>
              </div>
              <div className="all">
                <h6>Итого:</h6>
                <h5>£54.55</h5>
              </div>
            </div>
          </div>
          <div className="variant">
            <div className="imgand">
              <img src="./public/image/melk.png" alt="" />
              <h2>ПОЧТА РОССИИ МЕЛКИЕ ПАКЕТЫ</h2>
            </div>
            <div className="roadInfo">
              <div className="time">
                <h6>Сроки:</h6>
                <h5>10-14 дней</h5>
              </div>
              <div className="delPrice">
                <h6>Стоимость доставки:</h6>
                <h5>от £13.00</h5>
              </div>
              <div className="all">
                <h6>Итого:</h6>
                <h5>£90.50</h5>
              </div>
            </div>
          </div>
        </div>
        <div className="step">
          <h1>4 простых шага для ваших покупок в Великобритании </h1>
          <div className="cards">
            <div className="card">
              <img src="./public/image/chose.png" alt="" />
              <h2>
              вы ВЫБИРАЕТЕ ТОВАР
              </h2>
              <p>в английском магазине, оплачиваете и указываете <span className="green">адрес склада </span> OkeyPost</p>
            </div>
            <div className="card">
              <img src="./public/image/sklad.png" alt="" />
              <h2>
              ПОКУПКИ ПРИХОДЯТ НА СКЛАД
              </h2>
              <p>и появляются в вашем личном кабинете на нашем сайте</p>
            </div>
            <div className="card">
              <img src="./public/image/home.png" alt="" />
              <h2>
              ОТПРАВЛЯЕМ ИХ К ВАМ ДОМОЙ
              </h2>
              <p>в надежной упаковке, по выгодной цене и очень быстро</p>
            </div>
            <div className="card">
              <img src="./public/image/pochta.png" alt="" />
              <h2>
              ЗАБИРАЕТЕ
свою ПОСЫЛКУ
              </h2>
              <p>в пункте выдачи, на почте или с курьером</p>
            </div>
          </div>
          <h3>Не хотите разбираться самостоятельно, наши мастера шопинга с радостью купят все товары за вас.</h3>
          <button className="fastBtn">Быстрая покупка</button>
        </div>
      </div>
    </div>
  );
}

export default Road;
