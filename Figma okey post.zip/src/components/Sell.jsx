import React from "react";
import { FaLongArrowAltLeft } from "react-icons/fa";
import { FaArrowRightLong } from "react-icons/fa6";
import "./sell.css";

function Sell() {
  return (
    <div className="container">
      <div className="sell">
        <h1>Насколько выгодно покупать?</h1>
        <div className="goods">
          <div className="leftt">
            <FaLongArrowAltLeft />
          </div>
          <div className="good">
            <img src="./public/image/cloth.png" alt="" />
            <h2>Одежда</h2>
          </div>
          <div className="good">
            <img src="./public/image/elec.png" alt="" />
            <h2>Электроника</h2>
          </div>
          <div className="good">
            <img src="./public/image/bag.png" alt="" />
            <h2>Аксессуары</h2>
          </div>
          <div className="good">
            <img src="./public/image/child.png" alt="" />
            <h2>Для детей</h2>
          </div>
          <div className="good">
            <img src="./public/image/sport.png" alt="" />
            <h2>Для спорта</h2>
          </div>
          <div className="good">
            <img src="./public/image/ksometic.png" alt="" />
            <h2>Косметика</h2>
          </div>
          <div className="rightt">
            <FaArrowRightLong />
          </div>
        </div>
        <div className="info">
          <div className="russia">
            <h3>Columbia Barlow Pass 550 Turbodown Jacket</h3>
            <div className="price">
              <img src="./public/image/russia.png" alt="" />
              <div className="dollar">
                <h5>Цена в России</h5>
                <h4>7891,46₽</h4>
              </div>
            </div>
          </div>
          <div className="cloth">
            <img src="./public/image/kurtka.png" alt="" />
          </div>
          <div className="uk">
            <h3>
              Доставка одежды из Великобритании от <span>£7.79</span>
            </h3>
            <div className="price">
              <img src="./public/image/uk.png" alt="" />
              <div className="dollar">
                <h5>Цена в UK</h5>
                <h4 className="green">£80.62</h4>
              </div>
            </div>
          </div>
        </div>
        <div className="econom">
          <div className="tshirt">
            <img className="backt" src="./public/image/tshirt.png" alt="" />
            <div className="leftt">
              <FaLongArrowAltLeft />
            </div>
          </div>
          <div className="days">
            <h4>Срок доставки примерно 10 дней</h4>
            <h3>
              Вы экономите до <span>$119.56</span>
            </h3>
          </div>
          <div className="shirt">
            <img className="backs" src="./public/image/shirt.png" alt="" />
            <div className="leftt">
              <FaArrowRightLong />
            </div>
          </div>
        </div>
        <div className="adverts">
            <div className="advert">
                <img src="./public/image/calc.png" alt="" />
                <h5>Экономия до 70%</h5>
            </div>
            <div className="advert">
                <img src="./public/image/product.png" alt="" />
                <h5>Только подлинная продукция</h5>
            </div>
            <div className="advert">
                <img src="./public/image/deliver.png" alt="" />
                <h5>Оперативная доставка</h5>
            </div>
            <div className="advert">
                <img src="./public/image/tovar.png" alt="" />
                <h5>Огромный выбор товаров</h5>
            </div>
        </div>
      </div>
    </div>
  );
}

export default Sell;
