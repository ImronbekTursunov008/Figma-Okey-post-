import React from 'react'
import './modal.css'
import { IoMdClose } from "react-icons/io";
function Modal({modal,setModal,smsModal,setSmsModal}) {
  const backModal = ()=>{
    setModal(false)
  }
  return (
    <div className='modal'>
        <div onClick={backModal} className='close'>
        <IoMdClose />
        </div>
      <h2>Выполните вход в ваш личный кабинет </h2>
      <div className='youPhone'>
        <h5>Номер телефона:</h5>
        <input type="text" />
      </div>
      <div className='youEmail'>
        <h5>Ваш email:</h5>
        <input type="text" />
      </div>
      <div className='youPassword'>
        <h5>Ваш пароль:</h5>
        <input type="text" />
      </div>
      <p><span className='green'>Восстановление пароля</span> или <span className='green'>быстрая регистрация</span> </p>
      <div className='go'>
        <button onClick={()=>{
            setModal(false)
            setSmsModal(true)
        }} className='sign_In'>Войти</button>
        <div className='ourSocials'>
            <img src="./public/image/forModal/google.png" alt="" />
            <img src="./public/image/forModal/facebook.png" alt="" />
            <img src="./public/image/forModal/vkontakte.png" alt="" />
        </div>
      </div>
    </div>
  )
}

export default Modal