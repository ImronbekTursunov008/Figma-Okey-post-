import React from 'react'
import { IoMdClose } from "react-icons/io";

function SmsModal({smsModal,setSmsModal}) {
    const backSms = ()=>{
        setSmsModal(false)
      }
      const  endClick = ()=>{
        setSmsModal(false)
      }
  return (
    <div className='smsModal'>
    <div onClick={backSms} className='close'>
        <IoMdClose />
        </div>
        <h2>Введите код из СМС
для водтверждения </h2>
        <div className='Code'>
        <h5>Код и СМС:</h5>
        <input type="text" />
      </div>
      <button onClick={endClick} className='sign_In'>Войти</button>
    </div>
  )
}

export default SmsModal