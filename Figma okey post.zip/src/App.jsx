import { useState } from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import './App.css'
import Footer from './components/Footer'
import Main from './components/Main'
import Navbar from './components/Navbar'
import All from './components2/All'
import Blog from './components2/Blog'
import Bonus from './components2/Bonus'
import Howbuy from './components2/Howbuy'
import Magazine from './components2/Magazine'
import Modal from './Modal/Modal'
import SmsModal from './Modal/SmsModal'

function App() {
  const [modal , setModal] = useState(false)
  const [smsModal , setSmsModal] = useState(false)
  return (
    <div className='page'>
      {modal && <Modal smsModal = {smsModal} setSmsModal = {setSmsModal}  modal = {modal} setModal = {setModal}/>}
      {smsModal && <SmsModal smsModal = {smsModal} setSmsModal = {setSmsModal} />}
      <BrowserRouter>
      <Navbar modal = {modal} setModal = {setModal} />
      <Routes>
        <Route path='/' element = {<Main/>}/>
        <Route path='/howbuy' element = {<Howbuy/>}/>
        <Route path='/blog' element = {<Blog/>}/>
        <Route path='/magazine' element = {<Magazine/>}/>
        <Route path='/bonus' element = {<Bonus/>}/>
      </Routes>
      <Footer/>
      </BrowserRouter>
    </div>
  )
}

export default App
