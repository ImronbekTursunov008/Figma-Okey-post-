import React from "react";
import All from "./All";
import "./blog.css";

function Blog() {
  return (
    <div className="blog">
      <div className="titBlog">
        <div className="containers">
          <h5>Главная / Блог</h5>
          <h1>Блог</h1>
        </div>
      </div>
      <div className="blogi">
        <div className="blogs">
            <img src="./public/image/b1.png" alt="" />
            <h1>Интернет-магазин Urban Outfitters в UK: обзор</h1>
            <div className="timess">
                <h6>22.10.2021</h6>
                <h5>Читать: 8 минут</h5>
            </div>
        </div>
        <div className="blogs">
            <img src="./public/image/b2.png" alt="" />
            <h1>Overstock. Брендовые товары
по доступным ценам</h1>
<div className="timess">
    <h6>22.10.2021</h6>
    <h5>Читать: 8 минут</h5>
</div>
        </div>
        <div className="blogs">
            <img src="./public/image/b3.png" alt="" />
            <h1>Skechers с Amazon. Удобная
обувь для всей семьи</h1>
<div className="timess">
    <h6>22.10.2021</h6>
    <h5>Читать: 8 минут</h5>
</div>
        </div>
        <div className="blogs">
            <img src="./public/image/b4.png" alt="" />
            <h1>16 лучших подарков с Амазона
в 2021 году</h1>
<div className="timess">
    <h6>22.10.2021</h6>
    <h5>Читать: 8 минут</h5>
</div>
        </div>
        <div className="blogs">
            <img src="./public/image/b5.png" alt="" />
            <h1>Target — семейный супермаркет
с ценами от 300 рублей!</h1>
<div className="timess">
    <h6>22.10.2021</h6>
    <h5>Читать: 8 минут</h5>
</div>
        </div>
        <div className="blogs">
            <img src="./public/image/b6.png" alt="" />
            <h1>Английский магазин RIPNDIP. Покупаем самовыражение</h1>
            <div className="timess">
                <h6>22.10.2021</h6>
                <h5>Читать: 8 минут</h5>
            </div>
        </div>
        <div className="blogs">
            <img src="./public/image/b7.png" alt="" />
            <h1>Nautica. Элитные товары из Англии по низким ценам</h1>
            <div className="timess">
                <h6>22.10.2021</h6>
                <h5>Читать: 8 минут</h5>
            </div>
        </div>
        <div className="blogs">
            <img src="./public/image/b8.png" alt="" />
            <h1>Forever 21 - покупаем джинсы
за 1 500 рублей</h1>
<div className="timess">
    <h6>22.10.2021</h6>
    <h5>Читать: 8 минут</h5>
</div>
        </div>
        <div className="blogs">
            <img src="./public/image/b9.png" alt="" />
            <h1>Как купить кроссовки Balenciaga на 30 000 рублей дешевле?</h1>
            <div className="timess">
                <h6>22.10.2021</h6>
                <h5>Читать: 8 минут</h5>
            </div>
        </div>
        <div className="blogs">
            <img src="./public/image/b10.png" alt="" />
            <h1>Топ-7 самых дорогих сумок
Louis Vuitton</h1>
<div className="timess">
    <h6>22.10.2021</h6>
    <h5>Читать: 8 минут</h5>
</div>
        </div>
        <div className="blogs">
            <img src="./public/image/b11.png" alt="" />
            <h1>BH Cosmetics Galaxy. Галактика красоты и ухода </h1>
            <div className="timess">
                <h6>22.10.2021</h6>
                <h5>Читать: 8 минут</h5>
            </div>
        </div>
        <div className="blogs">
            <img src="./public/image/b12.png" alt="" />
            <h1>“Вансы”. Крутые кеды, которые не выйдут из моды никогда!</h1>
            <div className="timess">
                <h6>22.10.2021</h6>
                <h5>Читать: 8 минут</h5>
            </div>
        </div>
      </div>
      <All/>
    </div>
  );
}

export default Blog;
