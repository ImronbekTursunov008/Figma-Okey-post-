import React from 'react'
import './All.css'

function All() {
  return (
    <div className='All'>
        <div className="container">
        <h1>Остались вопросы? Спросите нас в соцсетях!</h1>
        <div className='socials'>
            <img src="./public/image/whatsap.png" alt="" />
            <img src="./public/image/viber.png" alt="" />
            <img src="./public/image/chat.png" alt="" />
        </div>
        </div>
    </div>
  )
}

export default All