import React from 'react'
import All from './All'
import './howbuy.css'

function Howbuy() {
  return (
    <div className='howbuy'>
            <div className="study">
                <div className="containers">
                    <h5>Главная  /  Как покупать</h5>
                    <h1>Научим покупать в Великобритании!</h1>
                    <h2>и экономить до 70%</h2>
                    <button className='adressUk'>Получить адрес в UK</button>
                </div>
            </div>
        <div className="stepby">
            <h1>Покупать в Великобритании очень просто</h1>
            <p className='tit'
            >Английские магазины не доставляют в Россию, но это не проблема. С OkeyPost можно покупать по лучшим ценам и экономить на доставке. Мы получим ваши посылки, надежно упакуем и отправим их к вам домой.</p>
             <div className="steps">
             <div className="stepp">
                <img src="./public/image/1step.png" alt="" />
                <div className='infoStep'>
                    <div className='information'>
                        <span className='numStep'>01</span>
                        <h3>Получаем адрес для покупок в магазинах Великобритании </h3>
                    </div>
                    <p>Okeypost поможет притвориться американцем и не переплачивать. Для этого нужно зарегистрироваться в нашем сервисе. После регистрации вам станут доступны два адреса в Англии, которые вы сможете указывать при оформлении заказов в интернет-магазинах.</p>
                </div>
            </div>      
            <div className="stepp">
                <img src="./public/image/precent.png" alt="" />
                <div className='infoStep'>
                    <div className='information'>
                        <span className='numStep'>02</span>
                        <h3>Идём за покупками в онлайн-магазины</h3>
                    </div>
                    <p>Выбираем нужные товары в магазинах Англии. Расплачиваемся, как обычно, в качестве адреса доставки указываем координаты одного из складов Okeypost. Оформить покупки можно самостоятельно или с нашей помощью. Вот список того, <span className='green'>что покупать нельзя.</span> </p>
                </div>
            </div>  
            <div className="stepp">
                <img src="./public/image/salls.png" alt="" />
                <div className='infoStep'>
                    <div className='information'>
                        <span className='numStep'>03</span>
                        <h3>Следим за перемещением посылки до склада</h3>
                    </div>
                    <p>После оформление заказа магазин пришлет трек-номер посылки на ваш e-mail и отправит вещи на наш склад. Через 5-7 дней покупки придут к нам, мы поместим их в специальное хранилище, закрепленное за вашим аккаунтом.</p>
                </div>
            </div>  
            <div className="stepp">
                <img src="./public/image/goodjob.png" alt="" />
                <div className='infoStep'>
                    <div className='information'>
                        <span className='numStep'>04</span>
                        <h3>Оплачиваем доставку и покупки отправляются домой</h3>
                    </div>
                    <p>Мы сообщим, когда ваши покупки поступят на склад. Вы сможете заказать что-то еще в других магазинах и отправить все одной посылкой (так выгоднее). До 30 дней покупки будут храниться бесплатно.
Когда все товары поступили на склад, выбирайте способ доставки, мы надежно все упакуем и отправим вам, сообщив трек-номер.</p>
                </div>
            </div>  
            <div className="stepp">
                <img src="./public/image/korzinka.png" alt="" />
                <div className='infoStep'>
                    <div className='information'>
                        <span className='numStep'>05</span>
                        <h3>Получаем посылку и спешим сделать новый заказ</h3>
                    </div>
                    <p>Примерно через 2 недели посылка приедет к вам домой, в пункт выдачи заказов или на почту. Получаем покупки и радуемся :)</p>
                </div>
            </div>   
            <button className='ukBtn'>Получить адрес в UK</button> 
             </div>
        </div>
      <All/>
    </div>
  )
}

export default Howbuy