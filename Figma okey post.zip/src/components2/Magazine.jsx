import React from "react";
import All from "./All";
import "./magazine.css";

function Magazine() {
  return (
    <div className="magazine">
      <div className="magaz">
        <div className="containers">
          <h5>Главная / Популярные магазины</h5>
          <h1>Популярные магазины</h1>
        </div>
      </div>
      <div className="containerchik">
        <div className="firmas">
          <div className="firma">
            <img src="./public/image/magaz/1.png" alt="" />
            <h5>Primark (Форма заказа)</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/2.png" alt="" />
            <h5>H&M</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/3.png" alt="" />
            <h5>Mangooutlet</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/4.png" alt="" />
            <h5>Next</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/5.png" alt="" />
            <h5>Sportdirect</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/6.png" alt="" />
            <h5>Clothing at Tesco</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/7.png" alt="" />
            <h5>George at ASDA</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/8.png" alt="" />
            <h5>Accessorize</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/9.png" alt="" />
            <h5>Adidas UK</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/10.png" alt="" />
            <h5>Amazon</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/11.png" alt="" />
            <h5>ASOS</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/12.png" alt="" />
            <h5>Boohoo</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/13.png" alt="" />
            <h5>Crocs</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/14.png" alt="" />
            <h5>Ebay</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/15.png" alt="" />
            <h5>Matalan</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/16.png" alt="" />
            <h5>Mothercare</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/17.png" alt="" />
            <h5>New Look</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/18.png" alt="" />
            <h5>Puma</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/19.png" alt="" />
            <h5>Timberland</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/20.png" alt="" />
            <h5>Showroomprive</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/21.png" alt="" />
            <h5>Brand Alley</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/22.png" alt="" />
            <h5>M&S</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/23.png" alt="" />
            <h5>Clarks</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/24.png" alt="" />
            <h5>Zara</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/25.png" alt="" />
            <h5>Mango</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/26.png" alt="" />
            <h5>Zulily</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/27.png" alt="" />
            <h5>Panachekids</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/28.png" alt="" />
            <h5>Betterware</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/29.png" alt="" />
            <h5>Tucci Store</h5>
          </div>
          <div className="firma">
            <img src="./public/image/magaz/30.png" alt="" />
            <h5>Mini Mode</h5>
          </div>
        </div>
      </div>
      <All />
    </div>
  );
}

export default Magazine;
