import React from "react";
import "./bonus.css";

function Bonus() {
  return (
    <div className="bonus">
      <div className="payBonus">
        <div className="containers">
          <h5>Главная / Бонусы и партнёрская программа</h5>
          <h1>Бонусы и партнёрская программа</h1>
          <h2>Платим $3 с каждой отправленной посылки</h2>
          <button className="bonusBtn">Начать зарабатывать</button>
        </div>
      </div>
      <div className="Earn">
      <h1>Зарабатывать с нами — проще простого:</h1>
      <div className="specials">
        <div className="special">
          <img src="./public/image/bonus/1.png" alt="" />
          <h2>Дарим скидку 10% вашим друзьям и подписчикам</h2>
          <p>На их первую отправленную посылку. Вам есть чем мотивировать зарегистрироваться именно по вашему реферальному коду или ссылке.</p>
        </div>
        <div className="special">
          <img src="./public/image/bonus/2.png" alt="" />
          <h2>Платим по £3 за отправленную посылку </h2>
          <p>Когда клиент, привлеченный по вашей ссылке, отправляет посылку – на ваш счет поступает $3. Вы можете оплачивать этими деньгами ваши посылки или выводить их себе на счет.</p>
        </div>
        <div className="special">
          <img src="./public/image/bonus/3.png" alt="" />
          <h2>Промо на любой вкус</h2>
          <p>Автоматические или персональные реферальные коды для отправки друзьям или подписчикам в мессенджеры или социальные сети, а также реферальные ссылки и баннеры для ваших сайтов.</p>
        </div>
        <div className="special">
          <img src="./public/image/bonus/4.png" alt="" />
          <h2>Выплаты по запросу</h2>
          <p>Платим по первому вашему требованию без задержек и других сложностей. Если на счету менее $50 – вы можете тратить их на оплату товаров или доставки. Если больше – выводить на свой счет.</p>
        </div>
        <div className="special">
          <img src="./public/image/bonus/5.png" alt="" />
          <h2>Начисляем кэшбэк £1 на 1 посылку</h2>
          <p>За каждую отправленную посылку , возможность оплатить после бонусного счета в 10 фунтов </p>
        </div>
      </div>
      </div>
      <div className='connect'>
        <div className="connect_container">
        <img src="./public/image/bonus/rocket.png" alt="" />
        <div className="connectInfo">
          <h1>Готовы начать зарабатывать вместе с нами?</h1>
        <p>Присоединяйтесь к партнерской программе Okeypost.com уже сегодня!</p>
        <button className="connectBtn">Присоедениться</button>
        </div>
        </div>
    </div>
    </div>
  );
}

export default Bonus;
